import { ref } from 'vue'
import { db } from '@/db'

const KEY = 'zf.publishedRevision'

function read(): number {
  try {
    return Number(localStorage.getItem(KEY) || 0) || 0
  } catch {
    return 0
  }
}

export const publishedRevision = ref(read())

export function markPublishedLocally(revision: number) {
  publishedRevision.value = revision
  try {
    localStorage.setItem(KEY, String(revision))
  } catch {
    /* ignore */
  }
}

/** 让新设备也能从数据库设置里恢复「上次发布版本」 */
export async function loadPublishedRevision(): Promise<number> {
  try {
    const row = await db().get<{ value: string }>("SELECT value FROM site_settings WHERE key = 'publishedRevision'")
    if (!row?.value) return publishedRevision.value
    const parsed = Number(JSON.parse(row.value))
    if (Number.isFinite(parsed) && parsed > publishedRevision.value) {
      markPublishedLocally(parsed)
    }
  } catch {
    /* 数据库尚未就绪时忽略 */
  }
  return publishedRevision.value
}

export function usePublishState() {
  return { publishedRevision, markPublishedLocally }
}
